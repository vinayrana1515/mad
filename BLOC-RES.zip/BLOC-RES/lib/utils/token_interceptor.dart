import 'package:blocdemo/utils/token_store.dart';
import 'package:dio/dio.dart';

class TokenInterceptor extends Interceptor {
  @override
  void onRequest(
    RequestOptions options,
    RequestInterceptorHandler handler,
  ) {
    print("Token Value is ${TokenStore.readToken('mytoken')}");
    handler.next(options);
  }
}
