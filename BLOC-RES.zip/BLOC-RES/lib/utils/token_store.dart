import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class TokenStore {
  static final storage = FlutterSecureStorage();
  TokenStore._() {}
  static Future<String> readToken(String tokenKey) async {
    return await storage.read(key: tokenKey).toString();
  }
}
