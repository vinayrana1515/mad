import 'package:blocdemo/utils/token_interceptor.dart';
import 'package:dio/dio.dart';

class ApiClient {
  Dio _dio = Dio();
  Future<Response> get(url) {
    return _dio.get(url);
  }

  registerInterceptors() {
    _dio.interceptors.add(TokenInterceptor());
  }
}
