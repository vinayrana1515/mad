import 'package:blocdemo/bloc/counter_bloc.dart';
import 'package:blocdemo/cubit/counter_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class Operations extends StatelessWidget {
  const Operations({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Bloc Cubit , Get the Instance of Bloc Cubit
    CounterCubit cubit = BlocProvider.of<CounterCubit>(context);
    CounterBloc bloc = BlocProvider.of<CounterBloc>(context);
    return Container(
      child: Row(children: [
        ElevatedButton(
          child: Text('Cubit Plus'),
          onPressed: () {
            cubit.plus(); // Function call of Cubit
            // Call Cubit
          },
        ),
        ElevatedButton(
            onPressed: () {
              bloc.add(PlusEvent()); // Add the PlusEvent
              // It call the on (Listener) Bloc File
            },
            child: Text('Bloc Plus'))
      ]),
    );
  }
}
