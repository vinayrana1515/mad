import 'package:flutter/material.dart';

// class LayoutDemo extends StatefulWidget {
//   const LayoutDemo({Key? key}) : super(key: key);

//   @override
//   State<LayoutDemo> createState() => _LayoutDemoState();
// }

//class _LayoutDemoState extends State<LayoutDemo> {
class LayoutDemo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: LayoutBuilder(
        builder: ((context, constraints) {
          print("Layout Builder Call ${constraints.maxWidth}");
          if (constraints.maxWidth <= 480) {
            return Container(
              width: 100,
              height: 100,
              color: Colors.red,
            );
          } else {
            return Row(
              children: [
                Container(
                  width: 100,
                  height: 100,
                  color: Colors.amber,
                ),
                Container(
                  width: 100,
                  height: 100,
                  color: Colors.redAccent,
                )
              ],
            );
          }
        }),
      )),
    );
  }
}
